import six

str_types = six.string_types + (six.text_type,)
