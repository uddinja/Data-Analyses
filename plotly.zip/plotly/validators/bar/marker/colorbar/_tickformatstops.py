import _plotly_utils.basevalidators


class TickformatstopsValidator(
    _plotly_utils.basevalidators.CompoundArrayValidator
):

    def __init__(
        self,
        plotly_name='tickformatstops',
        parent_name='bar.marker.colorbar',
        **kwargs
    ):
        super(TickformatstopsValidator, self).__init__(
            plotly_name=plotly_name,
            parent_name=parent_name,
            data_class_str='Tickformatstop',
            data_docs="""
            dtickrange
                range [*min*, *max*], where *min*, *max* -
                dtick values which describe some zoom level, it
                is possible to omit *min* or *max* value by
                passing *null*
            enabled
                Determines whether or not this stop is used. If
                `false`, this stop is ignored even within its
                `dtickrange`.
            name
                When used in a template, named items are
                created in the output figure in addition to any
                items the figure already has in this array. You
                can modify these items in the output figure by
                making your own item with `templateitemname`
                matching this `name` alongside your
                modifications (including `visible: false` or
                `enabled: false` to hide it). Has no effect
                outside of a template.
            templateitemname
                Used to refer to a named item in this array in
                the template. Named items from the template
                will be created even without a matching item in
                the input figure, but you can modify one by
                making an item with `templateitemname` matching
                its `name`, alongside your modifications
                (including `visible: false` or `enabled: false`
                to hide it). If there is no template or no
                matching item, this item will be hidden unless
                you explicitly show it with `visible: true`.
            value
                string - dtickformat for described zoom level,
                the same as *tickformat*""",
            **kwargs
        )
