from ._line import Line
from ._gradient import Gradient
from ._colorbar import ColorBar
from plotly.graph_objs.scatter.marker import colorbar
