from ._hoverlabel import Hoverlabel
from plotly.graph_objs.layout.annotation import hoverlabel
from ._font import Font
