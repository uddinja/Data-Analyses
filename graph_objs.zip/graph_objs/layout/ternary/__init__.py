from ._domain import Domain
from ._caxis import Caxis
from plotly.graph_objs.layout.ternary import caxis
from ._baxis import Baxis
from plotly.graph_objs.layout.ternary import baxis
from ._aaxis import Aaxis
from plotly.graph_objs.layout.ternary import aaxis
