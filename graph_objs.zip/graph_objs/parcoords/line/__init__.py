from ._colorbar import ColorBar
from plotly.graph_objs.parcoords.line import colorbar
